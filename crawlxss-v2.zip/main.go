package main

import (
	"bufio"
	"bytes"
	"context"
	"crypto/tls"
	"encoding/json"
	"flag"
	"fmt"
	"io"
	"log"
	"math/rand"
	"net"
	"net/http"
	"net/http/cookiejar"
	"net/url"
	"os"
	"os/exec"
	"regexp"
	"sort"
	"strings"
	"sync"
	"time"

	"github.com/projectdiscovery/subfinder/v2/pkg/runner"
	"golang.org/x/net/html"
)

var userAgents = []string{
	"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
	"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
	"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:121.0) Gecko/20100101 Firefox/121.0",
	"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.1 Safari/605.1.15",
	"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
	"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Edge/120.0.0.0",
	"Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:121.0) Gecko/20100101 Firefox/121.0",
	"Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:121.0) Gecko/20100101 Firefox/121.0",
	"Mozilla/5.0 (Windows NT 11.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
	"Mozilla/5.0 (X11; Linux x86_64; rv:121.0) Gecko/20100101 Firefox/121.0",
}

type CrawlResult struct {
	URL                 string
	ReflectionFound     bool
	ReflectionFoundGET  []string
	ReflectionFoundPOST []string
	GetParams           []string
	PostParams          []string
}

type FormInput struct {
	ParamName  string
	ParamValue string
	Method     string
}

type Crawler struct {
	client         *http.Client
	payload        string
	visited        map[string]bool
	mu             sync.Mutex
	results        []CrawlResult
	maxDepth       int
	currentDepth   int
	targetDomain   string
	baseDomain     string
	waybackURLs    map[string]bool
	seenSignatures map[string]bool
	useWayback     bool
	staticExtRe    *regexp.Regexp
	apiPathRe      *regexp.Regexp
	outputFile     string
	fileMu         sync.Mutex
}

func NewCrawler(maxDepth int, targetURL string, useWayback bool, outputFile string) *Crawler {
	transport := &http.Transport{
		TLSClientConfig: &tls.Config{InsecureSkipVerify: true},
		MaxIdleConns:    200,
		MaxIdleConnsPerHost: 100,
		IdleConnTimeout: 90 * time.Second,
		DisableKeepAlives: false,
	}

	parsedURL, _ := url.Parse(targetURL)
	baseDomain := extractBaseDomain(parsedURL.Host)

	staticExtRe := regexp.MustCompile(`(?i)\.(js|css|png|jpg|jpeg|gif|svg|woff|woff2|ico|pdf|zip|bmp|ttf|eot|otf|webp|txt|xml|json|mp3|mp4|avi|mov|flv|swf|doc|docx|xls|xlsx|ppt|pptx)(?:[/?#]|$)`)
	apiPathRe := regexp.MustCompile(`(?i)(?:://api\.|/api(?:/|\?|$))`)

	jar, _ := createCookieJar()

	return &Crawler{
		client: &http.Client{
			Transport: transport,
			Timeout:   30 * time.Second,
			Jar:       jar,
			CheckRedirect: func(req *http.Request, via []*http.Request) error {
				if len(via) >= 15 {
					return http.ErrUseLastResponse
				}
				return nil
			},
		},
		payload:        "\"><maheer>",
		visited:        make(map[string]bool),
		results:        []CrawlResult{},
		maxDepth:       maxDepth,
		currentDepth:   0,
		targetDomain:   parsedURL.Host,
		baseDomain:     baseDomain,
		waybackURLs:    make(map[string]bool),
		seenSignatures: make(map[string]bool),
		useWayback:     useWayback,
		staticExtRe:    staticExtRe,
		apiPathRe:      apiPathRe,
		outputFile:     outputFile,
	}
}

func createCookieJar() (http.CookieJar, error) {
	jar, err := cookiejar.New(nil)
	if err != nil {
		return nil, err
	}
	return jar, nil
}

func deduplicateStrings(slice []string) []string {
	seen := make(map[string]bool)
	result := []string{}
	for _, s := range slice {
		if !seen[s] {
			seen[s] = true
			result = append(result, s)
		}
	}
	return result
}

func deduplicateInterfaces(slice []interface{}) []interface{} {
	seen := make(map[string]bool)
	result := []interface{}{}
	for _, s := range slice {
		str, ok := s.(string)
		if ok && !seen[str] {
			seen[str] = true
			result = append(result, s)
		}
	}
	return result
}

func (c *Crawler) saveResultRealtime(result CrawlResult) {
	c.fileMu.Lock()
	defer c.fileMu.Unlock()

	var existingData map[string]interface{}
	
	fileData, err := os.ReadFile(c.outputFile)
	if err == nil && len(fileData) > 0 {
		json.Unmarshal(fileData, &existingData)
	}
	
	if existingData == nil {
		existingData = map[string]interface{}{
			"target":         c.targetDomain,
			"payload":        c.payload,
			"get_params":     []string{},
			"post_params":    []string{},
			"get_reflection":  []string{},
			"post_reflection": []string{},
		}
	}

	getParams, _ := existingData["get_params"].([]interface{})
	for _, p := range result.GetParams {
		getParams = append(getParams, p)
	}
	existingData["get_params"] = deduplicateInterfaces(getParams)

	postParams, _ := existingData["post_params"].([]interface{})
	for _, p := range result.PostParams {
		postParams = append(postParams, p)
	}
	existingData["post_params"] = deduplicateInterfaces(postParams)

	getReflection, _ := existingData["get_reflection"].([]interface{})
	for _, u := range result.ReflectionFoundGET {
		getReflection = append(getReflection, u)
	}
	existingData["get_reflection"] = deduplicateInterfaces(getReflection)

	postReflection, _ := existingData["post_reflection"].([]interface{})
	for _, u := range result.ReflectionFoundPOST {
		postReflection = append(postReflection, u)
	}
	existingData["post_reflection"] = deduplicateInterfaces(postReflection)

	file, err := os.Create(c.outputFile)
	if err != nil {
		return
	}
	defer file.Close()

	encoder := json.NewEncoder(file)
	encoder.SetIndent("", "  ")
	encoder.Encode(existingData)
}

var multiPartTLDs = []string{
	".co.uk", ".org.uk", ".ac.uk", ".gov.uk", ".me.uk", ".net.uk",
	".co.jp", ".or.jp", ".ne.jp", ".ac.jp", ".go.jp",
	".com.au", ".net.au", ".org.au", ".edu.au", ".gov.au",
	".co.nz", ".org.nz", ".net.nz", ".govt.nz",
	".co.in", ".org.in", ".net.in", ".gov.in", ".ac.in",
	".com.br", ".org.br", ".net.br", ".gov.br",
	".co.za", ".org.za", ".net.za", ".gov.za",
	".com.mx", ".org.mx", ".gob.mx",
	".com.cn", ".org.cn", ".net.cn", ".gov.cn",
	".com.tw", ".org.tw", ".net.tw", ".gov.tw",
	".com.hk", ".org.hk", ".net.hk", ".gov.hk",
	".com.sg", ".org.sg", ".net.sg", ".gov.sg",
	".co.kr", ".or.kr", ".ne.kr", ".go.kr",
	".com.my", ".org.my", ".net.my", ".gov.my",
	".co.id", ".or.id", ".web.id", ".go.id",
	".com.ph", ".org.ph", ".net.ph", ".gov.ph",
	".co.th", ".or.th", ".in.th", ".go.th",
	".com.vn", ".org.vn", ".net.vn", ".gov.vn",
	".com.ar", ".org.ar", ".net.ar", ".gov.ar",
	".com.co", ".org.co", ".net.co", ".gov.co",
	".com.pe", ".org.pe", ".net.pe", ".gob.pe",
	".com.ve", ".org.ve", ".net.ve", ".gov.ve",
	".com.ec", ".org.ec", ".net.ec", ".gov.ec",
	".com.eg", ".org.eg", ".net.eg", ".gov.eg",
	".co.il", ".org.il", ".net.il", ".gov.il",
	".com.sa", ".org.sa", ".net.sa", ".gov.sa",
	".com.ae", ".org.ae", ".net.ae", ".gov.ae",
	".com.tr", ".org.tr", ".net.tr", ".gov.tr",
	".com.ua", ".org.ua", ".net.ua", ".gov.ua",
	".com.pl", ".org.pl", ".net.pl", ".gov.pl",
	".co.at", ".or.at",
	".com.pt", ".org.pt",
	".com.es", ".org.es", ".nom.es",
	".com.it", ".org.it",
	".com.fr", ".org.fr",
	".com.de", ".org.de",
	".com.nl", ".org.nl",
	".com.be", ".org.be",
	".com.gr", ".org.gr",
	".com.ro", ".org.ro",
	".com.ru", ".org.ru", ".net.ru",
}

func extractBaseDomain(host string) string {
	host = strings.TrimPrefix(host, "www.")
	hostLower := strings.ToLower(host)
	
	for _, tld := range multiPartTLDs {
		if strings.HasSuffix(hostLower, tld) {
			withoutTLD := host[:len(host)-len(tld)]
			parts := strings.Split(withoutTLD, ".")
			if len(parts) >= 1 {
				return parts[len(parts)-1] + tld
			}
			return host
		}
	}
	
	parts := strings.Split(host, ".")
	if len(parts) >= 2 {
		return strings.Join(parts[len(parts)-2:], ".")
	}
	return host
}

func extractBaseParamName(param string) string {
	if strings.Contains(param, "-") {
		parts := strings.Split(param, "-")
		if len(parts) > 0 && parts[0] != "" {
			return parts[0]
		}
	}
	if strings.Contains(param, "_") {
		parts := strings.Split(param, "_")
		if len(parts) > 0 && parts[0] != "" {
			return parts[0]
		}
	}
	return param
}

func getParamVariants(param string) []string {
	variants := []string{param}
	baseParam := extractBaseParamName(param)
	if baseParam != param {
		variants = append(variants, baseParam)
	}
	return variants
}

func (c *Crawler) isAllowedDomain(targetURL string) bool {
	parsedURL, err := url.Parse(targetURL)
	if err != nil {
		return false
	}

	urlHost := strings.ToLower(parsedURL.Host)
	targetHost := strings.ToLower(c.targetDomain)
	baseDomain := strings.ToLower(c.baseDomain)

	if urlHost == targetHost {
		return true
	}

	urlBaseDomain := strings.ToLower(extractBaseDomain(urlHost))
	if urlBaseDomain == baseDomain {
		return true
	}

	if strings.HasSuffix(urlHost, "."+baseDomain) {
		return true
	}

	return false
}

func (c *Crawler) isStaticOrAPI(rawURL string) bool {
	decoded, err := url.QueryUnescape(rawURL)
	if err != nil {
		decoded = rawURL
	}
	if c.staticExtRe.MatchString(decoded) {
		return true
	}
	if c.apiPathRe.MatchString(decoded) {
		return true
	}
	return false
}

func (c *Crawler) extractParamNames(rawURL string) []string {
	decoded, err := url.QueryUnescape(rawURL)
	if err != nil {
		decoded = rawURL
	}
	parsedURL, err := url.Parse(decoded)
	if err != nil {
		return nil
	}
	query := parsedURL.RawQuery
	if query == "" && strings.Contains(parsedURL.Path, "?") {
		parts := strings.SplitN(parsedURL.Path, "?", 2)
		if len(parts) == 2 {
			query = parts[1]
		}
	}
	if query == "" && strings.Contains(decoded, "?") {
		parts := strings.SplitN(decoded, "?", 2)
		if len(parts) == 2 {
			query = parts[1]
		}
	}
	if query == "" {
		return nil
	}
	values, err := url.ParseQuery(query)
	if err != nil {
		paramRe := regexp.MustCompile(`([^&=]+)=`)
		matches := paramRe.FindAllStringSubmatch(query, -1)
		var params []string
		for _, m := range matches {
			if len(m) > 1 && m[1] != "" {
				params = append(params, strings.ToLower(strings.TrimSpace(m[1])))
			}
		}
		return params
	}
	var params []string
	for k := range values {
		if k != "" {
			params = append(params, strings.ToLower(strings.TrimSpace(k)))
		}
	}
	sort.Strings(params)
	return params
}

func (c *Crawler) getURLSignature(rawURL string) string {
	decoded, err := url.QueryUnescape(rawURL)
	if err != nil {
		decoded = rawURL
	}
	parsedURL, err := url.Parse(decoded)
	if err != nil {
		return ""
	}
	params := c.extractParamNames(rawURL)
	if len(params) == 0 {
		return ""
	}
	path := parsedURL.Path
	if path == "" {
		path = "/"
	}
	return fmt.Sprintf("%s%s?%s", parsedURL.Host, path, strings.Join(params, ","))
}

func (c *Crawler) shouldProcessURL(rawURL string) bool {
	if c.isStaticOrAPI(rawURL) {
		return false
	}
	params := c.extractParamNames(rawURL)
	if len(params) == 0 {
		return false
	}
	sig := c.getURLSignature(rawURL)
	if sig == "" {
		return false
	}
	c.mu.Lock()
	defer c.mu.Unlock()
	if c.seenSignatures[sig] {
		return false
	}
	c.seenSignatures[sig] = true
	return true
}

func (c *Crawler) fetchWaybackURLs(domain string) []string {
	var urls []string
	cleanDomain := domain
	if strings.HasPrefix(cleanDomain, "http://") {
		cleanDomain = strings.TrimPrefix(cleanDomain, "http://")
	}
	if strings.HasPrefix(cleanDomain, "https://") {
		cleanDomain = strings.TrimPrefix(cleanDomain, "https://")
	}
	cleanDomain = strings.TrimSuffix(cleanDomain, "/")
	cleanDomain = strings.Split(cleanDomain, "/")[0]

	cmd := exec.Command("waybackurls", cleanDomain)
	stdout, err := cmd.StdoutPipe()
	if err != nil {
		fmt.Printf("[!] Error creating waybackurls pipe: %v\n", err)
		return urls
	}
	if err := cmd.Start(); err != nil {
		fmt.Printf("[!] Error starting waybackurls: %v\n", err)
		return urls
	}

	paramURLMap := make(map[string]string)
	scanner := bufio.NewScanner(stdout)
	for scanner.Scan() {
		rawURL := scanner.Text()
		if rawURL == "" {
			continue
		}
		if c.isStaticOrAPI(rawURL) {
			continue
		}
		if !c.isAllowedDomain(rawURL) {
			continue
		}
		params := c.extractParamNames(rawURL)
		if len(params) == 0 {
			continue
		}
		parsedURL, err := url.Parse(rawURL)
		if err != nil {
			continue
		}
		if parsedURL.Scheme == "" {
			rawURL = "https://" + rawURL
			parsedURL, err = url.Parse(rawURL)
			if err != nil {
				continue
			}
		}
		for _, param := range params {
			baseParam := extractBaseParamName(param)
			paramKey := fmt.Sprintf("%s%s?%s", parsedURL.Host, parsedURL.Path, baseParam)
			if _, exists := paramURLMap[paramKey]; !exists {
				paramURLMap[paramKey] = rawURL
			}
			if baseParam != param {
				originalKey := fmt.Sprintf("%s%s?%s", parsedURL.Host, parsedURL.Path, param)
				if _, exists := paramURLMap[originalKey]; !exists {
					paramURLMap[originalKey] = rawURL
				}
			}
		}
	}
	cmd.Wait()

	seenURLs := make(map[string]bool)
	for _, u := range paramURLMap {
		if !seenURLs[u] {
			seenURLs[u] = true
			urls = append(urls, u)
		}
	}
	return urls
}

func (c *Crawler) getRandomUserAgent() string {
	return userAgents[rand.Intn(len(userAgents))]
}

func (c *Crawler) fetchURL(targetURL string) (string, error) {
	req, err := http.NewRequest("GET", targetURL, nil)
	if err != nil {
		return "", err
	}

	req.Header.Set("User-Agent", c.getRandomUserAgent())
	req.Header.Set("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8")
	req.Header.Set("Accept-Language", "en-US,en;q=0.5")
	req.Header.Set("Connection", "keep-alive")

	resp, err := c.client.Do(req)
	if err != nil {
		return "", err
	}
	defer resp.Body.Close()

	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return "", err
	}

	return string(body), nil
}

func (c *Crawler) getJSStringContext(body string, idx int) string {
	scriptStartRe := regexp.MustCompile(`(?i)<script[^>]*>`)
	scriptEndRe := regexp.MustCompile(`(?i)</script>`)

	scriptStarts := scriptStartRe.FindAllStringIndex(body, -1)
	scriptEnds := scriptEndRe.FindAllStringIndex(body, -1)

	inScript := false
	scriptStart := 0
	for i, start := range scriptStarts {
		if start[1] <= idx {
			if i < len(scriptEnds) && scriptEnds[i][0] > idx {
				inScript = true
				scriptStart = start[1]
				break
			} else if i >= len(scriptEnds) {
				inScript = true
				scriptStart = start[1]
				break
			}
		}
	}

	if !inScript {
		return ""
	}

	jsContent := body[scriptStart:idx]

	inSingleQuote := false
	inDoubleQuote := false
	inBacktick := false
	inSingleLineComment := false
	inMultiLineComment := false

	for i := 0; i < len(jsContent); i++ {
		ch := jsContent[i]

		if inSingleLineComment {
			if ch == '\n' {
				inSingleLineComment = false
			}
			continue
		}

		if inMultiLineComment {
			if ch == '*' && i+1 < len(jsContent) && jsContent[i+1] == '/' {
				inMultiLineComment = false
				i++
			}
			continue
		}

		if !inSingleQuote && !inDoubleQuote && !inBacktick {
			if ch == '/' && i+1 < len(jsContent) {
				next := jsContent[i+1]
				if next == '/' {
					inSingleLineComment = true
					i++
					continue
				}
				if next == '*' {
					inMultiLineComment = true
					i++
					continue
				}
			}
		}

		if ch == '\\' && i+1 < len(jsContent) {
			i++
			continue
		}

		if ch == '\'' && !inDoubleQuote && !inBacktick {
			inSingleQuote = !inSingleQuote
		} else if ch == '"' && !inSingleQuote && !inBacktick {
			inDoubleQuote = !inDoubleQuote
		} else if ch == '`' && !inSingleQuote && !inDoubleQuote {
			inBacktick = !inBacktick
		}
	}

	if inSingleQuote {
		return "single"
	}
	if inDoubleQuote {
		return "double"
	}
	if inBacktick {
		return "backtick"
	}
	return ""
}

func (c *Crawler) isInsideJSString(body string, idx int) bool {
	return c.getJSStringContext(body, idx) != ""
}

func (c *Crawler) isInsideHTMLComment(body string, idx int) bool {
	commentStart := strings.LastIndex(body[:idx], "<!--")
	if commentStart == -1 {
		return false
	}
	commentEnd := strings.Index(body[commentStart:], "-->")
	if commentEnd == -1 {
		return true
	}
	return commentStart+commentEnd > idx
}

func (c *Crawler) isInsideHTMLAttribute(body string, idx int) bool {
	searchStart := idx - 500
	if searchStart < 0 {
		searchStart = 0
	}
	before := body[searchStart:idx]

	lastOpenTag := strings.LastIndex(before, "<")
	if lastOpenTag == -1 {
		return false
	}

	lastCloseTag := strings.LastIndex(before, ">")
	if lastCloseTag > lastOpenTag {
		return false
	}

	tagContent := before[lastOpenTag:]

	eqIdx := strings.LastIndex(tagContent, "=")
	if eqIdx == -1 {
		return false
	}

	afterEq := strings.TrimLeft(tagContent[eqIdx+1:], " \t")
	if len(afterEq) == 0 {
		return false
	}

	quoteChar := afterEq[0]
	if quoteChar != '"' && quoteChar != '\'' {
		return false
	}

	restAfterQuote := afterEq[1:]
	closingQuote := strings.Index(restAfterQuote, string(quoteChar))

	return closingQuote == -1
}

func (c *Crawler) isInsideCDATASection(body string, idx int) bool {
	cdataStart := strings.LastIndex(body[:idx], "<![CDATA[")
	if cdataStart == -1 {
		return false
	}
	cdataEnd := strings.Index(body[cdataStart:], "]]>")
	if cdataEnd == -1 {
		return true
	}
	return cdataStart+cdataEnd > idx
}

func (c *Crawler) isExploitableReflection(body string, payload string, idx int) bool {
	if c.isInsideHTMLComment(body, idx) {
		if !strings.Contains(payload, "-->") {
			return false
		}
	}

	jsContext := c.getJSStringContext(body, idx)
	if jsContext != "" {
		canBreakOut := false
		switch jsContext {
		case "single":
			if strings.Contains(payload, "'") || strings.Contains(strings.ToLower(payload), "</script>") {
				canBreakOut = true
			}
		case "double":
			if strings.Contains(payload, "\"") || strings.Contains(strings.ToLower(payload), "</script>") {
				canBreakOut = true
			}
		case "backtick":
			if strings.Contains(payload, "`") || strings.Contains(payload, "${") || strings.Contains(strings.ToLower(payload), "</script>") {
				canBreakOut = true
			}
		}
		if !canBreakOut {
			return false
		}
	}

	if c.isInsideHTMLAttribute(body, idx) {
		searchStart := idx - 200
		if searchStart < 0 {
			searchStart = 0
		}
		before := body[searchStart:idx]
		lastEq := strings.LastIndex(before, "=")
		if lastEq != -1 {
			afterEq := strings.TrimLeft(before[lastEq+1:], " \t")
			if len(afterEq) > 0 {
				quoteChar := string(afterEq[0])
				if !strings.Contains(payload, quoteChar) && !strings.Contains(payload, ">") {
					return false
				}
			}
		}
	}

	return true
}

func (c *Crawler) testReflection(targetURL string, param string, value string, method string) (bool, string, error) {
	parsedURL, err := url.Parse(targetURL)
	if err != nil {
		return false, "", err
	}

	var req *http.Request

	if method == "POST" {
		formData := url.Values{}
		formData.Set(param, value)
		req, err = http.NewRequest("POST", parsedURL.String(), strings.NewReader(formData.Encode()))
		if err != nil {
			return false, "", err
		}
		req.Header.Set("Content-Type", "application/x-www-form-urlencoded")
	} else {
		query := parsedURL.Query()
		query.Set(param, value)
		parsedURL.RawQuery = query.Encode()
		req, err = http.NewRequest("GET", parsedURL.String(), nil)
		if err != nil {
			return false, "", err
		}
	}

	req.Header.Set("User-Agent", c.getRandomUserAgent())
	req.Header.Set("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")

	resp, err := c.client.Do(req)
	if err != nil {
		return false, "", err
	}
	defer resp.Body.Close()

	contentType := resp.Header.Get("Content-Type")
	if strings.Contains(contentType, "application/json") {
		return false, "", nil
	}
	if strings.Contains(contentType, "image/") {
		return false, "", nil
	}
	if strings.Contains(contentType, "application/pdf") {
		return false, "", nil
	}
	if strings.Contains(contentType, "application/octet-stream") {
		return false, "", nil
	}

	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return false, "", err
	}

	bodyStr := string(body)
	if !strings.Contains(bodyStr, value) {
		return false, "", nil
	}

	idx := strings.Index(bodyStr, value)
	if idx == -1 {
		return false, "", nil
	}

	if idx > 0 && idx+len(value) < len(bodyStr) {
		start := idx - 50
		if start < 0 {
			start = 0
		}
		end := idx + len(value) + 50
		if end > len(bodyStr) {
			end = len(bodyStr)
		}
		surrounding := bodyStr[start:end]
		if strings.Contains(surrounding, "&quot;") || strings.Contains(surrounding, "&#34;") || strings.Contains(surrounding, "&gt;") || strings.Contains(surrounding, "&lt;") {
			encCheck := bodyStr[idx : idx+len(value)]
			if encCheck != value {
				return false, "", nil
			}
		}
	}

	if !c.isExploitableReflection(bodyStr, value, idx) {
		return false, "", nil
	}

	exploitable := false
	searchIdx := 0
	for {
		foundIdx := strings.Index(bodyStr[searchIdx:], value)
		if foundIdx == -1 {
			break
		}
		actualIdx := searchIdx + foundIdx
		if c.isExploitableReflection(bodyStr, value, actualIdx) {
			exploitable = true
			break
		}
		searchIdx = actualIdx + len(value)
	}

	if !exploitable {
		return false, "", nil
	}

	return true, "reflected", nil
}

func (c *Crawler) detectReflectionContext(body string, payload string) string {
	idx := strings.Index(body, payload)
	if idx == -1 {
		return ""
	}

	start := idx - 100
	if start < 0 {
		start = 0
	}
	end := idx + len(payload) + 100
	if end > len(body) {
		end = len(body)
	}
	surrounding := body[start:end]

	beforePayload := body[start:idx]
	afterPayload := ""
	if idx+len(payload) < end {
		afterPayload = body[idx+len(payload) : end]
	}

	tagPattern := regexp.MustCompile(`<[^>]*$`)
	if tagPattern.MatchString(beforePayload) {
		closingPattern := regexp.MustCompile(`^[^>]*>`)
		if closingPattern.MatchString(afterPayload) || strings.Contains(afterPayload, ">") {
			return "html-attribute"
		}
		return "html-tag"
	}

	scriptPattern := regexp.MustCompile(`(?i)<script[^>]*>[^<]*$`)
	if scriptPattern.MatchString(beforePayload) {
		return "javascript"
	}

	stylePattern := regexp.MustCompile(`(?i)<style[^>]*>[^<]*$`)
	if stylePattern.MatchString(beforePayload) {
		return "css"
	}

	commentPattern := regexp.MustCompile(`<!--[^>]*$`)
	if commentPattern.MatchString(beforePayload) {
		return "html-comment"
	}

	quotedAttrPattern := regexp.MustCompile(`=\s*["'][^"']*$`)
	if quotedAttrPattern.MatchString(beforePayload) {
		return "html-attribute-value"
	}

	if strings.Contains(surrounding, "<") || strings.Contains(surrounding, ">") {
		return "html-body"
	}

	return "text"
}

func (c *Crawler) findHiddenParameters(htmlContent string) []string {
	var params []string
	seenParams := make(map[string]bool)

	emptyVarPattern := regexp.MustCompile(`(?m)['"]([a-zA-Z_$][a-zA-Z0-9_$]*)['"]\s*:\s*['"]['"]\s*[,}]`)
	matches := emptyVarPattern.FindAllStringSubmatch(htmlContent, -1)
	for _, match := range matches {
		if len(match) > 1 && !seenParams[match[1]] {
			params = append(params, match[1])
			seenParams[match[1]] = true
		}
	}

	emptyAssignPattern := regexp.MustCompile(`(?m)var\s+([a-zA-Z_$][a-zA-Z0-9_$]*)\s*=\s*['"]['"]`)
	varMatches := emptyAssignPattern.FindAllStringSubmatch(htmlContent, -1)
	for _, match := range varMatches {
		if len(match) > 1 && !seenParams[match[1]] {
			params = append(params, match[1])
			seenParams[match[1]] = true
		}
	}

	return params
}

func (c *Crawler) extractAllForms(htmlContent string, baseURL string) []FormInput {
	var inputs []FormInput
	doc, err := html.Parse(strings.NewReader(htmlContent))
	if err != nil {
		return inputs
	}

	var extractFromNode func(*html.Node, string, string, map[string]string)
	extractFromNode = func(n *html.Node, formAction string, formMethod string, formInputs map[string]string) {
		if n.Type == html.ElementNode && n.Data == "form" {
			formMethod = "GET"
			formAction = baseURL
			formInputs = make(map[string]string)

			for _, attr := range n.Attr {
				switch attr.Key {
				case "method":
					formMethod = strings.ToUpper(attr.Val)
				case "action":
					if attr.Val != "" {
						parsedBase, _ := url.Parse(baseURL)
						parsedAction, err := url.Parse(attr.Val)
						if err == nil {
							formAction = parsedBase.ResolveReference(parsedAction).String()
						}
					}
				}
			}
		}

		if n.Type == html.ElementNode && n.Data == "input" {
			var inputType, name, value string
			for _, attr := range n.Attr {
				switch attr.Key {
				case "type":
					inputType = attr.Val
				case "name":
					name = attr.Val
				case "value":
					value = attr.Val
				}
			}
			if name != "" && formInputs != nil {
				formInputs[name] = value
				if inputType != "submit" && inputType != "button" && inputType != "reset" {
					inputs = append(inputs, FormInput{
						ParamName:  name,
						ParamValue: formAction,
						Method:     formMethod,
					})
				}
			}
		}

		for child := n.FirstChild; child != nil; child = child.NextSibling {
			extractFromNode(child, formAction, formMethod, formInputs)
		}
	}
	extractFromNode(doc, baseURL, "GET", nil)

	return inputs
}

func (c *Crawler) extractLinks(htmlContent string, baseURL string) []string {
	var links []string
	doc, err := html.Parse(strings.NewReader(htmlContent))
	if err != nil {
		return links
	}

	base, err := url.Parse(baseURL)
	if err != nil {
		return links
	}

	var traverse func(*html.Node)
	traverse = func(n *html.Node) {
		if n.Type == html.ElementNode && n.Data == "a" {
			for _, attr := range n.Attr {
				if attr.Key == "href" {
					linkURL, err := url.Parse(attr.Val)
					if err != nil {
						continue
					}
					absoluteURL := base.ResolveReference(linkURL)
					absoluteURLStr := absoluteURL.String()
					if c.isAllowedDomain(absoluteURLStr) {
						links = append(links, absoluteURLStr)
					}
				}
			}
		}
		for child := n.FirstChild; child != nil; child = child.NextSibling {
			traverse(child)
		}
	}
	traverse(doc)

	return links
}

func (c *Crawler) extractParameters(targetURL string) []string {
	var params []string
	seenParams := make(map[string]bool)

	decoded, err := url.QueryUnescape(targetURL)
	if err != nil {
		decoded = targetURL
	}

	parsedURL, err := url.Parse(decoded)
	if err != nil {
		parsedURL, _ = url.Parse(targetURL)
	}

	if parsedURL == nil {
		return params
	}

	query := parsedURL.RawQuery
	if query == "" && strings.Contains(decoded, "?") {
		parts := strings.SplitN(decoded, "?", 2)
		if len(parts) == 2 {
			query = parts[1]
		}
	}
	if query == "" && strings.Contains(parsedURL.Path, "?") {
		parts := strings.SplitN(parsedURL.Path, "?", 2)
		if len(parts) == 2 {
			query = parts[1]
		}
	}

	if query != "" {
		if idx := strings.Index(query, "#"); idx != -1 {
			query = query[:idx]
		}

		values, err := url.ParseQuery(query)
		if err == nil {
			for key := range values {
				if key != "" && !seenParams[key] {
					seenParams[key] = true
					params = append(params, key)
				}
			}
		} else {
			paramRe := regexp.MustCompile(`([^&=]+)=`)
			matches := paramRe.FindAllStringSubmatch(query, -1)
			for _, m := range matches {
				if len(m) > 1 && m[1] != "" {
					key := strings.TrimSpace(m[1])
					if !seenParams[key] {
						seenParams[key] = true
						params = append(params, key)
					}
				}
			}
		}
	}

	return params
}

func (c *Crawler) crawl(targetURL string, depth int) {
	if depth > c.maxDepth {
		return
	}

	c.mu.Lock()
	if c.visited[targetURL] {
		c.mu.Unlock()
		return
	}
	c.visited[targetURL] = true
	c.mu.Unlock()

	fmt.Printf("[=] Crawling: %s (Depth: %d/%d)\n", targetURL, depth, c.maxDepth)

	htmlContent, err := c.fetchURL(targetURL)
	if err != nil {
		fmt.Printf("[!] Error fetching %s: %v\n", targetURL, err)
		return
	}

	result := CrawlResult{
		URL:                 targetURL,
		ReflectionFound:     false,
		ReflectionFoundGET:  []string{},
		ReflectionFoundPOST: []string{},
		GetParams:           []string{},
		PostParams:          []string{},
	}

	hiddenParams := c.findHiddenParameters(htmlContent)

	formInputs := c.extractAllForms(htmlContent, targetURL)

	if len(hiddenParams) > 0 {
		fmt.Printf("    [i] Found %d hidden parameters in source code\n", len(hiddenParams))
	}

	if len(formInputs) > 0 {
		fmt.Printf("    [i] Found %d form input fields\n", len(formInputs))
	}

	urlParams := c.extractParameters(targetURL)
	testedParams := make(map[string]bool)
	for _, param := range urlParams {
		variants := getParamVariants(param)
		for _, testParam := range variants {
			if testedParams[testParam] {
				continue
			}
			testedParams[testParam] = true
			if testParam != param {
				fmt.Printf("    [>] Testing URL parameter: %s (base of %s)\n", testParam, param)
			} else {
				fmt.Printf("    [>] Testing URL parameter: %s\n", testParam)
			}
			reflected, _, err := c.testReflection(targetURL, testParam, c.payload, "GET")
			if err == nil && reflected {
				result.ReflectionFound = true
				parsedURL, _ := url.Parse(targetURL)
				query := parsedURL.Query()
				query.Set(testParam, c.payload)
				parsedURL.RawQuery = query.Encode()
				vulnURL := parsedURL.String()
				result.ReflectionFoundGET = append(result.ReflectionFoundGET, vulnURL)
				paramURL := fmt.Sprintf("%s://%s%s?%s=%s", parsedURL.Scheme, parsedURL.Host, parsedURL.Path, testParam, testParam)
				result.GetParams = append(result.GetParams, paramURL)
				fmt.Printf("[+] REFLECTION FOUND: %s\n", vulnURL)
			}
		}
	}

	for _, param := range hiddenParams {
		variants := getParamVariants(param)
		for _, testParam := range variants {
			if testedParams[testParam] {
				continue
			}
			testedParams[testParam] = true
			if testParam != param {
				fmt.Printf("    [>] Testing hidden parameter: %s (base of %s)\n", testParam, param)
			} else {
				fmt.Printf("    [>] Testing hidden parameter: %s\n", testParam)
			}
			reflected, _, err := c.testReflection(targetURL, testParam, c.payload, "GET")
			if err == nil && reflected {
				result.ReflectionFound = true
				parsedURL, _ := url.Parse(targetURL)
				query := parsedURL.Query()
				query.Set(testParam, c.payload)
				parsedURL.RawQuery = query.Encode()
				vulnURL := parsedURL.String()
				result.ReflectionFoundGET = append(result.ReflectionFoundGET, vulnURL)
				paramURL := fmt.Sprintf("%s://%s%s?%s=%s", parsedURL.Scheme, parsedURL.Host, parsedURL.Path, testParam, testParam)
				result.GetParams = append(result.GetParams, paramURL)
				fmt.Printf("[+] REFLECTION FOUND: %s\n", vulnURL)
			}
		}
	}

	for _, input := range formInputs {
		variants := getParamVariants(input.ParamName)
		for _, testParam := range variants {
			if testedParams[testParam] {
				continue
			}
			testedParams[testParam] = true
			if testParam != input.ParamName {
				fmt.Printf("    [>] Testing form input: %s (base of %s, Method: %s, Action: %s)\n", testParam, input.ParamName, input.Method, input.ParamValue)
			} else {
				fmt.Printf("    [>] Testing form input: %s (Method: %s, Action: %s)\n", testParam, input.Method, input.ParamValue)
			}
			reflected, _, err := c.testReflection(input.ParamValue, testParam, c.payload, input.Method)
			if err == nil && reflected {
				result.ReflectionFound = true
				var vulnURL string
				parsedURL, _ := url.Parse(input.ParamValue)
				paramURL := fmt.Sprintf("%s://%s%s?%s=%s", parsedURL.Scheme, parsedURL.Host, parsedURL.Path, testParam, testParam)
				if input.Method == "GET" {
					query := parsedURL.Query()
					query.Set(testParam, c.payload)
					parsedURL.RawQuery = query.Encode()
					vulnURL = parsedURL.String()
					result.ReflectionFoundGET = append(result.ReflectionFoundGET, vulnURL)
					result.GetParams = append(result.GetParams, paramURL)
				} else {
					vulnURL = fmt.Sprintf("%s?%s=%s", input.ParamValue, testParam, c.payload)
					result.ReflectionFoundPOST = append(result.ReflectionFoundPOST, vulnURL)
					result.PostParams = append(result.PostParams, paramURL)
				}
				fmt.Printf("[+] REFLECTION FOUND: %s\n", vulnURL)
			}
		}
	}

	c.mu.Lock()
	c.results = append(c.results, result)
	c.mu.Unlock()

	if result.ReflectionFound {
		c.saveResultRealtime(result)
	}

	if depth < c.maxDepth {
		links := c.extractLinks(htmlContent, targetURL)
		fmt.Printf("    [i] Discovered %d links on this page\n", len(links))
		
		var wg sync.WaitGroup
		semaphore := make(chan struct{}, 20)

		for _, link := range links {
			wg.Add(1)
			go func(url string) {
				defer wg.Done()
				semaphore <- struct{}{}
				defer func() { <-semaphore }()
				c.crawl(url, depth+1)
			}(link)
		}
		wg.Wait()
	}
}

func (c *Crawler) processWaybackURL(targetURL string) {
	c.mu.Lock()
	if c.visited[targetURL] {
		c.mu.Unlock()
		return
	}
	c.visited[targetURL] = true
	c.mu.Unlock()

	fmt.Printf("[=] Testing Wayback URL: %s\n", targetURL)

	result := CrawlResult{
		URL:                 targetURL,
		ReflectionFound:     false,
		ReflectionFoundGET:  []string{},
		ReflectionFoundPOST: []string{},
		GetParams:           []string{},
		PostParams:          []string{},
	}

	urlParams := c.extractParameters(targetURL)
	testedParams := make(map[string]bool)
	for _, param := range urlParams {
		variants := getParamVariants(param)
		for _, testParam := range variants {
			if testedParams[testParam] {
				continue
			}
			testedParams[testParam] = true
			reflected, _, err := c.testReflection(targetURL, testParam, c.payload, "GET")
			if err == nil && reflected {
				result.ReflectionFound = true
				parsedURL, _ := url.Parse(targetURL)
				query := parsedURL.Query()
				query.Set(testParam, c.payload)
				parsedURL.RawQuery = query.Encode()
				vulnURL := parsedURL.String()
				result.ReflectionFoundGET = append(result.ReflectionFoundGET, vulnURL)
				paramURL := fmt.Sprintf("%s://%s%s?%s=%s", parsedURL.Scheme, parsedURL.Host, parsedURL.Path, testParam, testParam)
				result.GetParams = append(result.GetParams, paramURL)
				fmt.Printf("[+] REFLECTION FOUND: %s\n", vulnURL)
			}
		}
	}

	if result.ReflectionFound {
		c.mu.Lock()
		c.results = append(c.results, result)
		c.mu.Unlock()
		c.saveResultRealtime(result)
	}
}

func (c *Crawler) printResults() {
	fmt.Println("\n" + strings.Repeat("=", 80))
	fmt.Println("CRAWL RESULTS SUMMARY")
	fmt.Println(strings.Repeat("=", 80))

	var totalGET []string
	var totalPOST []string

	for _, result := range c.results {
		if len(result.ReflectionFoundGET) > 0 {
			totalGET = append(totalGET, result.ReflectionFoundGET...)
		}
		if len(result.ReflectionFoundPOST) > 0 {
			totalPOST = append(totalPOST, result.ReflectionFoundPOST...)
		}
	}

	if len(totalGET) > 0 {
		fmt.Println("\n[!] XSS REFLECTION FOUND (GET):")
		for _, u := range totalGET {
			fmt.Printf("    %s\n", u)
		}
	}

	if len(totalPOST) > 0 {
		fmt.Println("\n[!] XSS REFLECTION FOUND (POST):")
		for _, u := range totalPOST {
			fmt.Printf("    %s\n", u)
		}
	}

	fmt.Println("\n" + strings.Repeat("=", 80))
	fmt.Printf("Total URLs Crawled: %d\n", len(c.visited))
	fmt.Printf("XSS Reflections (GET): %d\n", len(totalGET))
	fmt.Printf("XSS Reflections (POST): %d\n", len(totalPOST))
	fmt.Printf("Total Vulnerabilities Found: %d\n", len(totalGET)+len(totalPOST))
	fmt.Println(strings.Repeat("=", 80))
}

func (c *Crawler) countVulnerabilities() int {
	count := 0
	for _, result := range c.results {
		if result.ReflectionFound {
			count++
		}
	}
	return count
}

func (c *Crawler) saveToFile(filename string) error {
	file, err := os.Create(filename)
	if err != nil {
		return err
	}
	defer file.Close()

	var totalGET []string
	var totalPOST []string
	var getParams []string
	var postParams []string

	for _, result := range c.results {
		if len(result.ReflectionFoundGET) > 0 {
			totalGET = append(totalGET, result.ReflectionFoundGET...)
		}
		if len(result.ReflectionFoundPOST) > 0 {
			totalPOST = append(totalPOST, result.ReflectionFoundPOST...)
		}
		if len(result.GetParams) > 0 {
			getParams = append(getParams, result.GetParams...)
		}
		if len(result.PostParams) > 0 {
			postParams = append(postParams, result.PostParams...)
		}
	}

	output := map[string]interface{}{
		"target":          c.targetDomain,
		"payload":         c.payload,
		"get_params":      deduplicateStrings(getParams),
		"post_params":     deduplicateStrings(postParams),
		"get_reflection":  deduplicateStrings(totalGET),
		"post_reflection": deduplicateStrings(totalPOST),
	}

	encoder := json.NewEncoder(file)
	encoder.SetIndent("", "  ")
	if err := encoder.Encode(output); err != nil {
		return err
	}

	fmt.Printf("\n[*] Results saved to: %s\n", filename)
	return nil
}

func enumerateSubdomains(domain string) []string {
	var subdomains []string

	cleanDomain := domain
	if strings.HasPrefix(cleanDomain, "http://") {
		cleanDomain = strings.TrimPrefix(cleanDomain, "http://")
	}
	if strings.HasPrefix(cleanDomain, "https://") {
		cleanDomain = strings.TrimPrefix(cleanDomain, "https://")
	}
	cleanDomain = strings.TrimSuffix(cleanDomain, "/")
	cleanDomain = strings.Split(cleanDomain, "/")[0]

	subfinderOpts := &runner.Options{
		Threads:            10,
		Timeout:            30,
		MaxEnumerationTime: 10,
	}

	log.SetFlags(0)
	log.SetOutput(io.Discard)

	subfinder, err := runner.NewRunner(subfinderOpts)
	if err != nil {
		fmt.Printf("[!] Failed to create subfinder runner: %v\n", err)
		return subdomains
	}

	output := &bytes.Buffer{}
	sourceMap, err := subfinder.EnumerateSingleDomainWithCtx(context.Background(), cleanDomain, []io.Writer{output})
	if err != nil {
		fmt.Printf("[!] Failed to enumerate subdomains: %v\n", err)
		return subdomains
	}

	seenSubdomains := make(map[string]bool)
	for subdomain := range sourceMap {
		if !seenSubdomains[subdomain] {
			seenSubdomains[subdomain] = true
			subdomains = append(subdomains, subdomain)
		}
	}

	return subdomains
}

func loadDomainsFromFile(filePath string) ([]string, error) {
	var domains []string
	file, err := os.Open(filePath)
	if err != nil {
		return nil, err
	}
	defer file.Close()
	scanner := bufio.NewScanner(file)
	for scanner.Scan() {
		line := strings.TrimSpace(scanner.Text())
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}
		domains = append(domains, line)
	}
	if err := scanner.Err(); err != nil {
		return nil, err
	}
	return domains, nil
}

func normalizeURL(input string) string {
	input = strings.TrimSpace(input)
	if !strings.HasPrefix(input, "http://") && !strings.HasPrefix(input, "https://") {
		return "https://" + input
	}
	return input
}

func stripProtocol(input string) string {
	input = strings.TrimSpace(input)
	input = strings.TrimPrefix(input, "https://")
	input = strings.TrimPrefix(input, "http://")
	input = strings.TrimSuffix(input, "/")
	return strings.Split(input, "/")[0]
}

func hasProtocol(input string) bool {
	return strings.HasPrefix(input, "http://") || strings.HasPrefix(input, "https://")
}

type probeResult struct {
	url        string
	statusCode int
	success    bool
}

func probeURL(client *http.Client, targetURL string, resultChan chan<- probeResult) {
	req, err := http.NewRequest("GET", targetURL, nil)
	if err != nil {
		resultChan <- probeResult{url: targetURL, success: false}
		return
	}

	req.Header.Set("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36")
	req.Header.Set("Accept", "*/*")
	req.Header.Set("Accept-Language", "en-US,en;q=0.9")
	req.Header.Set("Connection", "close")

	resp, err := client.Do(req)
	if err != nil {
		resultChan <- probeResult{url: targetURL, success: false}
		return
	}
	defer resp.Body.Close()
	io.Copy(io.Discard, resp.Body)

	resultChan <- probeResult{url: targetURL, statusCode: resp.StatusCode, success: true}
}

func probeProtocol(domain string) string {
	domain = stripProtocol(domain)

	transport := &http.Transport{
		TLSClientConfig: &tls.Config{
			InsecureSkipVerify: true,
			MinVersion:         tls.VersionTLS10,
		},
		DialContext: (&net.Dialer{
			Timeout:   5 * time.Second,
			KeepAlive: 5 * time.Second,
		}).DialContext,
		MaxIdleConns:          100,
		MaxIdleConnsPerHost:   10,
		IdleConnTimeout:       30 * time.Second,
		TLSHandshakeTimeout:   5 * time.Second,
		ExpectContinueTimeout: 1 * time.Second,
		DisableKeepAlives:     true,
	}

	client := &http.Client{
		Transport: transport,
		Timeout:   7 * time.Second,
		CheckRedirect: func(req *http.Request, via []*http.Request) error {
			return http.ErrUseLastResponse
		},
	}

	httpsURL := "https://" + domain
	httpURL := "http://" + domain

	resultChan := make(chan probeResult, 2)

	go probeURL(client, httpsURL, resultChan)
	go probeURL(client, httpURL, resultChan)

	var httpsResult, httpResult probeResult
	for i := 0; i < 2; i++ {
		result := <-resultChan
		if strings.HasPrefix(result.url, "https://") {
			httpsResult = result
		} else {
			httpResult = result
		}
	}

	if httpsResult.success && httpsResult.statusCode > 0 && httpsResult.statusCode < 500 {
		return httpsURL
	}

	if httpResult.success && httpResult.statusCode > 0 && httpResult.statusCode < 500 {
		return httpURL
	}

	if httpsResult.success {
		return httpsURL
	}

	if httpResult.success {
		return httpURL
	}

	return httpsURL
}

func probeProtocolBatch(domains []string, concurrency int) (map[string]string, []string) {
	results := make(map[string]string)
	var deadTargets []string
	var mu sync.Mutex

	transport := &http.Transport{
		TLSClientConfig: &tls.Config{
			InsecureSkipVerify: true,
			MinVersion:         tls.VersionTLS10,
		},
		DialContext: (&net.Dialer{
			Timeout:   5 * time.Second,
			KeepAlive: 5 * time.Second,
		}).DialContext,
		MaxIdleConns:          100,
		MaxIdleConnsPerHost:   10,
		IdleConnTimeout:       30 * time.Second,
		TLSHandshakeTimeout:   5 * time.Second,
		ExpectContinueTimeout: 1 * time.Second,
		DisableKeepAlives:     true,
	}

	client := &http.Client{
		Transport: transport,
		Timeout:   7 * time.Second,
		CheckRedirect: func(req *http.Request, via []*http.Request) error {
			return http.ErrUseLastResponse
		},
	}

	var wg sync.WaitGroup
	semaphore := make(chan struct{}, concurrency)

	for _, domain := range domains {
		wg.Add(1)
		go func(d string) {
			defer wg.Done()
			semaphore <- struct{}{}
			defer func() { <-semaphore }()

			cleanDomain := stripProtocol(d)
			httpsURL := "https://" + cleanDomain
			httpURL := "http://" + cleanDomain

			resultChan := make(chan probeResult, 2)

			go probeURL(client, httpsURL, resultChan)
			go probeURL(client, httpURL, resultChan)

			var httpsResult, httpResult probeResult
			for i := 0; i < 2; i++ {
				result := <-resultChan
				if strings.HasPrefix(result.url, "https://") {
					httpsResult = result
				} else {
					httpResult = result
				}
			}

			mu.Lock()
			if httpsResult.success && httpsResult.statusCode > 0 && httpsResult.statusCode < 500 {
				results[d] = httpsURL
			} else if httpResult.success && httpResult.statusCode > 0 && httpResult.statusCode < 500 {
				results[d] = httpURL
			} else if httpsResult.success && httpsResult.statusCode >= 500 {
				results[d] = httpsURL
			} else if httpResult.success && httpResult.statusCode >= 500 {
				results[d] = httpURL
			} else {
				deadTargets = append(deadTargets, d)
			}
			mu.Unlock()
		}(domain)
	}

	wg.Wait()
	return results, deadTargets
}

func main() {
	rand.Seed(time.Now().UnixNano())

	fmt.Println(`  ___                 ___  _____ ___ `)
	fmt.Println(` / __|_ _ __ ___ __ _| \ \/ / __/ __|`)
	fmt.Println(`| (__| '_/ _` + "`" + ` \ V  V / |>  <\__ \__ \`)
	fmt.Println(` \___|_| \__,_|\_/\_/|_/_/\_\___/___/ @Armx64`)
	fmt.Println()

	targetURL := flag.String("t", "", "Target URL to crawl")
	targetList := flag.String("l", "", "File containing list of domains/URLs to crawl")
	outputFile := flag.String("o", "crawl_results.json", "Output filename for results")
	maxDepth := flag.Int("d", 3, "Max crawl depth")
	useWayback := flag.Bool("w", false, "Enable wayback URL collection")
	concurrency := flag.Int("c", 20, "Concurrency for wayback URL testing")
	enumSubdomains := flag.Bool("e", false, "Enable subdomain enumeration using subfinder")

	flag.Parse()

	var targets []string
	var rawTargets []string

	if *targetList != "" {
		domains, err := loadDomainsFromFile(*targetList)
		if err != nil {
			fmt.Printf("Error reading list file: %v\n", err)
			os.Exit(1)
		}
		rawTargets = domains
	} else if *targetURL != "" {
		rawTargets = append(rawTargets, *targetURL)
	} else {
		fmt.Println("Error: Target URL (-t) or list file (-l) is required")
		fmt.Println("\nUsage:")
		flag.PrintDefaults()
		os.Exit(1)
	}

	if *enumSubdomains {
		var allSubdomains []string
		for _, target := range rawTargets {
			cleanDomain := stripProtocol(target)
			fmt.Printf("[*] Enumerating subdomains for: %s\n", cleanDomain)
			subdomains := enumerateSubdomains(cleanDomain)
			fmt.Printf("[+] Found %d subdomains for %s\n", len(subdomains), cleanDomain)
			allSubdomains = append(allSubdomains, subdomains...)
		}
		rawTargets = append(rawTargets, allSubdomains...)
	}

	fmt.Printf("[*] Probing %d targets for protocol detection...\n", len(rawTargets))
	probeResults, deadTargets := probeProtocolBatch(rawTargets, *concurrency)
	for _, target := range rawTargets {
		if finalURL, ok := probeResults[target]; ok {
			targets = append(targets, finalURL)
		}
	}
	fmt.Printf("[+] Alive: %d | Dead: %d\n", len(targets), len(deadTargets))

	fmt.Printf("\n[*] Total Targets: %d\n", len(targets))
	fmt.Printf("[*] Max Depth: %d\n", *maxDepth)
	fmt.Printf("[*] Output File: %s\n", *outputFile)
	fmt.Printf("[*] Wayback Mode: %v\n", *useWayback)
	fmt.Printf("[*] Subdomain Enumeration: %v\n", *enumSubdomains)
	fmt.Printf("[*] Using payload: \"><maheer>\n")
	fmt.Println(strings.Repeat("-", 80))

	var allResults []CrawlResult
	var totalVisited int
	var allCrawlers []*Crawler
	startTime := time.Now()

	for i, target := range targets {
		fmt.Printf("\n[*] Processing target %d/%d: %s\n\n", i+1, len(targets), target)

		parsedURL, err := url.Parse(target)
		if err != nil || parsedURL.Scheme == "" || parsedURL.Host == "" {
			fmt.Printf("[!] Invalid URL format for %s, skipping...\n", target)
			continue
		}

		crawler := NewCrawler(*maxDepth, target, *useWayback, *outputFile)
		crawler.crawl(target, 1)
		allCrawlers = append(allCrawlers, crawler)

		allResults = append(allResults, crawler.results...)
		totalVisited += len(crawler.visited)
	}

	if *useWayback {
		fmt.Println("\n[*] Starting Wayback URL collection and XSS testing...")

		waybackDomains := rawTargets[:len(rawTargets)]
		if *enumSubdomains {
			waybackDomains = []string{}
			for _, target := range rawTargets {
				cleanDomain := stripProtocol(target)
				isSubdomain := false
				for _, other := range rawTargets {
					otherClean := stripProtocol(other)
					if cleanDomain != otherClean && strings.HasSuffix(cleanDomain, "."+otherClean) {
						isSubdomain = true
						break
					}
				}
				if !isSubdomain {
					waybackDomains = append(waybackDomains, target)
				}
			}
		}

		processedWaybackDomains := make(map[string]bool)
		for _, domain := range waybackDomains {
			cleanDomain := stripProtocol(domain)
			if processedWaybackDomains[cleanDomain] {
				continue
			}
			processedWaybackDomains[cleanDomain] = true

			var matchingTarget string
			for _, target := range targets {
				parsedURL, err := url.Parse(target)
				if err != nil {
					continue
				}
				if strings.Contains(parsedURL.Host, cleanDomain) || strings.Contains(cleanDomain, parsedURL.Host) {
					matchingTarget = target
					break
				}
			}
			if matchingTarget == "" && len(targets) > 0 {
				matchingTarget = targets[0]
			}

			crawler := NewCrawler(*maxDepth, matchingTarget, *useWayback, *outputFile)

			fmt.Printf("\n[*] Fetching wayback URLs for %s...\n", cleanDomain)
			waybackURLs := crawler.fetchWaybackURLs(cleanDomain)
			fmt.Printf("[*] Found %d unique parameter-based URLs from wayback\n", len(waybackURLs))

			if len(waybackURLs) > 0 {
				var wg sync.WaitGroup
				semaphore := make(chan struct{}, *concurrency)

				for _, wbURL := range waybackURLs {
					wg.Add(1)
					go func(u string) {
						defer wg.Done()
						semaphore <- struct{}{}
						defer func() { <-semaphore }()
						crawler.processWaybackURL(u)
					}(wbURL)
				}
				wg.Wait()
			}

			allResults = append(allResults, crawler.results...)
			totalVisited += len(crawler.visited)
		}
	}

	elapsed := time.Since(startTime)
	fmt.Printf("\n[*] All targets completed in %v\n", elapsed)

	fmt.Println("\n" + strings.Repeat("=", 80))
	fmt.Println("FINAL RESULTS SUMMARY")
	fmt.Println(strings.Repeat("=", 80))

	var totalGET []string
	var totalPOST []string

	for _, result := range allResults {
		if len(result.ReflectionFoundGET) > 0 {
			totalGET = append(totalGET, result.ReflectionFoundGET...)
		}
		if len(result.ReflectionFoundPOST) > 0 {
			totalPOST = append(totalPOST, result.ReflectionFoundPOST...)
		}
	}

	if len(totalGET) > 0 {
		fmt.Println("\n[!] XSS REFLECTION FOUND (GET):")
		for _, u := range totalGET {
			fmt.Printf("    %s\n", u)
		}
	}

	if len(totalPOST) > 0 {
		fmt.Println("\n[!] XSS REFLECTION FOUND (POST):")
		for _, u := range totalPOST {
			fmt.Printf("    %s\n", u)
		}
	}

	fmt.Printf("\nTotal Targets Processed: %d\n", len(targets))
	fmt.Printf("Total URLs Crawled: %d\n", totalVisited)
	fmt.Printf("XSS Reflections (GET): %d\n", len(totalGET))
	fmt.Printf("XSS Reflections (POST): %d\n", len(totalPOST))
	fmt.Printf("Total Vulnerabilities Found: %d\n", len(totalGET)+len(totalPOST))
	fmt.Println(strings.Repeat("=", 80))

	if err := saveCombinedResults(*outputFile, targets, allResults); err != nil {
		fmt.Printf("[!] Error saving results: %v\n", err)
	}
}

func saveCombinedResults(filename string, targets []string, results []CrawlResult) error {
	file, err := os.Create(filename)
	if err != nil {
		return err
	}
	defer file.Close()

	var totalGET []string
	var totalPOST []string
	var getParams []string
	var postParams []string

	for _, result := range results {
		if len(result.ReflectionFoundGET) > 0 {
			totalGET = append(totalGET, result.ReflectionFoundGET...)
		}
		if len(result.ReflectionFoundPOST) > 0 {
			totalPOST = append(totalPOST, result.ReflectionFoundPOST...)
		}
		if len(result.GetParams) > 0 {
			getParams = append(getParams, result.GetParams...)
		}
		if len(result.PostParams) > 0 {
			postParams = append(postParams, result.PostParams...)
		}
	}

	output := map[string]interface{}{
		"targets":         targets,
		"payload":         "\"><maheer>",
		"get_params":      getParams,
		"post_params":     postParams,
		"get_reflection":  totalGET,
		"post_reflection": totalPOST,
	}

	encoder := json.NewEncoder(file)
	encoder.SetIndent("", "  ")
	if err := encoder.Encode(output); err != nil {
		return err
	}

	fmt.Printf("\n[*] Results saved to: %s\n", filename)
	return nil
}
